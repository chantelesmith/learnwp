<div id="wrapper" class="clearFix">
    <footer>
        <p>Copyright &copy; <?php echo date("Y"); echo " "; ?> My Great Blog. Photos by Ian Rogers.</p>
    </footer>
</div><!-- end wrapper -->
<?php wp_footer(); ?>
</body>
</html>