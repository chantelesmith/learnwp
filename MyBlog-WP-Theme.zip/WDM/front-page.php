<?php get_header(); ?>
    <div class="sliderArea">
	<?php putRevSlider("slider2") ?>
    </div>
    <div id="contentWrap">
        <div id="content"></div>
    </div>
<?php get_footer(); ?>